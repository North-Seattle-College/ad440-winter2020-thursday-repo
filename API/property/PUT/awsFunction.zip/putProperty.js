// Logging levels:
//Trace: Everything.
//Debug: What user entered, JSON request. What was implemented in the database. 
//(information about database entry for post, put request, returned get request)
//Info: What happened. POST request, PUT REQUEST, GET REQUEST, DELETE. Skeleton of what happened.
//Error: error, 400, 404, 405, 500 would show up



//node package for mysql connection
const mysql = require('mysql');

//credentials needed to connect
function mysql_connection(){
    var params={
        host     : process.env.RDS_HOSTNAME,
        user     : process.env.RDS_USERNAME,
        password : process.env.RDS_PASSWORD,
        port     : process.env.RDS_PORT,
        database : process.env.RDS_DATABASE
    };
    return mysql.createConnection(params);
}

console.trace("PUT Property by property_id -- function starting --");
console.info("Put Request for Property by property_id")
exports.handler = (event, context, callback) => {
    var connection = mysql_connection();
    console.trace("Successfully connected to the database")
    console.trace('connected as id ' + connection.threadId);
 
    
    //body parameters for changing data
    var queryParams = [
        event.body.property_name,
        event.body.property_type_id,
        event.body.property_address,
        event.body.property_city,
        event.body.property_state,
        event.body.property_zip,
        event.body.property_country
    ];
    //Property ID to know which property to update
    var property_id = event.body.property_id;
    
    console.debug("User entered in property_id:" + property_id + "Body params: " + queryParams)
    
    //mysql update statement
    var sql = "UPDATE property SET (property_name, property_type_id, property_address, property_city, property_state, property_zip, property_country) VALUES ( ?,?,?,?,?,?,?) WHERE property_id =" + property_id + ";"

    connection.query(sql,queryParams, (err, result) => {
        console.trace("Update Query initiated")
        if (err) {
            console.error("error", err)
            throw err;

        }
        else{
            console.info("Property Updated!" + result);
            connection.end();
            callback(null, "Property Updated: " + result);
        }
    });
};
console.trace("PUT Property by property_id -- function end ");


